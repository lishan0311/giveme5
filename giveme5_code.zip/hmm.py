import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from hmmlearn import hmm

df_market = pd.read_csv('bitcoin_2022.csv', index_col='start_time')
df_whale = pd.read_csv('bitcoun_exchange_whale_ratio_2022.csv', index_col='datetime')
df_count = pd.read_csv('bitcoun_transactions_count_2022.csv', index_col='datetime')
df_exchange = pd.read_csv('bitcoun_cryptoquant_exchange_netflow_2022.csv', index_col='datetime')

df_final = df_market[['volatility_24h', 'RSI', 'log_return']].copy()
df_final = df_final.join([
    df_whale['exchange_whale_ratio'],
    df_count['total_transactions_count'],
    df_exchange['exchange_netflow']
])

df_final.to_csv('hmm.csv', index=False)

# 1. Handling of missing values
df_final.fillna(method='bfill', inplace=True)

# 2. StandardScaler
scaler = StandardScaler()
scaled_values = scaler.fit_transform(df_final.values)
df_final.loc[:, :] = scaled_values

features = ['volatility_24h', 'RSI', 'log_return', 'exchange_whale_ratio', 'total_transactions_count', 'exchange_netflow']
X = df_final[features].values 

# 3. build model
n_states = 4
model = hmm.GaussianHMM(n_components=n_states, covariance_type="diag", n_iter=1000,random_state=42)
model.fit(X)

# 4. Perform hidden state prediction
hidden_states = model.predict(X)

# 5. State Interpretation Framework
state_definitions = {
    0: {
        'name': 'Bull Market',
        'criteria': {
            'log_return': 'High (>0.01)',
            'volatility': 'Medium',
            'RSI': 'Overbought (>50)',
            'transactions': 'High'
        }
    },
    1: {
        'name': 'Bear Market',
        'criteria': {
            'log_return': 'Negative (<0)',
            'volatility': 'High',
            'RSI': 'Oversold (<40)',
            'transactions': 'Medium'
        }
    },
    2: {
        'name': 'Volatile Market',
        'criteria': {
            'log_return': 'Neutral (~0)',
            'volatility': 'Extreme',
            'RSI': 'Neutral (40-60)',
            'transactions': 'Fluctuating'
        }
    },
    3: {
        'name': 'Sideways Market',
        'criteria': {
            'log_return': 'Neutral (~0)',
            'volatility': 'Low',
            'RSI': 'Neutral (40-60)',
            'transactions': 'Stable'
        }
    }
}

# 6. Automated State Mapping
state_stats = pd.DataFrame(index=range(n_states), columns=[
    'mean_volatility', 'mean_RSI', 'mean_log_return',
    'mean_whale_ratio', 'mean_transactions', 'mean_netflow',
    'state_duration'
])

for i in range(n_states):
    mask = hidden_states == i
    state_stats.loc[i] = [
        X[mask, 0].mean(), X[mask, 1].mean(), X[mask, 2].mean(),
        X[mask, 3].mean(), X[mask, 4].mean(), X[mask, 5].mean(),
        np.mean(np.diff(np.where(np.concatenate(([False], mask[:-1] != mask[1:], [True])))[0]))  ]


print("\nState Statistics:")
print(state_stats.round(3))

# 7. Dynamic Threshold Calculation
market_volatility_benchmark = X[:,0].mean()
rsi_overbought = 55 if state_stats['mean_RSI'].mean() > 50 else 50  # Adaptive threshold

state_mapping = {}
for i in range(n_states):
    stats = state_stats.loc[i]
    
    if (stats['mean_log_return'] > 0.008 and 
        stats['mean_RSI'] > rsi_overbought and
        stats['mean_volatility'] < market_volatility_benchmark):
        state_mapping[i] = 'Bull Market'
    elif (stats['mean_log_return'] < -0.005 and 
          stats['mean_volatility'] > market_volatility_benchmark):
        state_mapping[i] = 'Bear Market'
    elif stats['mean_volatility'] > market_volatility_benchmark * 1.5:
        state_mapping[i] = 'Volatile Market'
    else:
        state_mapping[i] = 'Sideways Market'

# 8. Enhanced Visualization
plt.figure(figsize=(16, 10))

# Price Action with Regimes
ax1 = plt.subplot(3,1,1)
for state in state_mapping:
    mask = hidden_states == state
    ax1.scatter(df_final.index[mask], X[mask, 2], 
                label=f'{state_mapping[state]} (State {state})',
                alpha=0.7, s=15)
ax1.set_title('Market Regime Classification')
ax1.set_ylabel('Log Returns')


# Volatility Analysis
ax2 = plt.subplot(3,1,2, sharex=ax1)
volatility_color = np.where(X[:,0] > market_volatility_benchmark, 
                           'red', 'green')
ax2.scatter(df_final.index, X[:,0], c=volatility_color, alpha=0.6, s=10)
ax2.axhline(market_volatility_benchmark, color='black', linestyle='--')
ax2.set_ylabel('Volatility')

# RSI Analysis
ax3 = plt.subplot(3,1,3, sharex=ax1)
ax3.plot(df_final.index, X[:,1], color='purple', alpha=0.6)
ax3.axhline(50, color='gray', linestyle='--')
ax3.set_ylabel('RSI')
ax3.set_xlabel('Time')

plt.tight_layout()
plt.legend()
plt.show()

log_prob, posteriors= model.score_samples(X) 

# 9. save to csv file
df_final['state_code'] = hidden_states
df_final['hmm_prob'] = posteriors.max(axis=1)

# state mapping
state_mapping = {
    0: 'Bull Market',
    1: 'Bear Market', 
    2: 'Volatile Market',
    3: 'Sideways Market'
}
df_final['market_state'] = df_final['state_code'].map(state_mapping)

df_final = df_final.reset_index(drop=True)  # reset index
df_final = df_final.rename(columns={'start_time': 'Date'})


result_df = pd.DataFrame({
    'Date': df_final['Date'],
    'Volatility': df_final['volatility_24h'],
    'RSI': df_final['RSI'],
    'Log_Return': df_final['log_return'],
    'state_code': df_final['state_code'],
    'Market_State': df_final['market_state'],
    'hmm_prob':df_final['hmm_prob']
})

result_df.to_csv('hmm_final.csv', index=False)