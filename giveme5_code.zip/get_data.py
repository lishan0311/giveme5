#market-price 

import requests
import pandas as pd
import  numpy as np
import time
from datetime import datetime

start_date = datetime(2022, 1, 1)
end_date = datetime(2022, 12, 31)

start_time = int(start_date.timestamp()) * 1000  
end_time = int(end_date.timestamp()) * 1000 

#Get Bitcoin candle data at 2022
url = f'https://api.datasource.cybotrade.rs/bybit-linear/candle?symbol=BTCUSDT&interval=4h&start_time={start_time}&end_time={end_time}'

headers = {
    "X-API-KEY": "9nvHJT2ud8KuQZs4s3bsIv4FiKs1GMoVReVLxhCwevI0v7uV"  
}

response = requests.get(url, headers=headers)

if response.status_code == 200:
    raw_data = response.json()['data']
    if raw_data:
        df = pd.DataFrame(raw_data, columns=['start_time', 'open', 'high', 'low', 'close', 'volume'])
        df['start_time'] = pd.to_datetime(df['start_time'], unit='ms')
        df[['open', 'high', 'low', 'close', 'volume']] = df[['open', 'high', 'low', 'close', 'volume']].astype(float)
        df.set_index('start_time', inplace=True)

        # ===Volatility===
        df['log_return'] = np.log(df['close'] / df['close'].shift(1))
        df['volatility_24h'] = df['log_return'].rolling(window=6).std()

        # ===RSI===
        delta = df['close'].diff()

        gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
        
        rs = gain / loss
        df['RSI'] = 100 - (100 / (1 + rs))

        df.to_csv('bitcoin_2020.csv')
else:
    print(f"request not successful， code：{response.status_code}")
