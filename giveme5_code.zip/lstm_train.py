# data processing
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from tensorflow import keras
from tensorflow.keras.callbacks import EarlyStopping


df = pd.read_csv('stock.csv', index_col='Date')

df['Close'] = np.log(df['Close'] + 1)

columns_to_normalize = ['Close']
scaler = MinMaxScaler()
scaler_values = scaler.fit_transform(df[columns_to_normalize])
df[columns_to_normalize] = scaler_values

df_scaled = pd.DataFrame(scaler_values, columns=['Close'], index=df.index)
df_scaled.head()

def create_sequence(data, window_size):
    X = []
    y = []
    for i in range(window_size, len(data)):
        X.append(data.iloc[i-window_size:i].values)
        y.append(data.iloc[i].values)
    return np.array(X), np.array(y)

window_size = 80
X, y = create_sequence(df_scaled, window_size)

# split dataset
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# train
model = keras.Sequential([
    keras.layers.LSTM(units =100, return_sequences=True, input_shape=(X_train.shape[1], X_train.shape[2])),
    keras.layers.Dropout(0.2),

    keras.layers.LSTM(units =100, return_sequences=True),
    keras.layers.Dropout(0.2),

    keras.layers.LSTM(units =100, return_sequences=False),
    keras.layers.Dropout(0.2),

    #output layer
    keras.layers.Dense(1)
])

model.compile(optimizer=keras.optimizers.Adam(learning_rate=0.005),
              loss='mean_squared_error',
              metrics=['RootMeanSquaredError'])

#early stopping
early_stopping = EarlyStopping(monitor='val_loss',
                              patience = 10,
                              restore_best_weights = True)

lstm_model = model.fit(X_train, y_train,
                       validation_split=0.2,
                       epochs = 100,
                       batch_size = 32,
                       callbacks = [early_stopping])

predicted = model.predict(X_test)
actual = y_test

predicted_buy_sell = (predicted > np.roll(predicted, 1)).astype(int)
actual_buy_sell = (actual > np.roll(actual, 1)).astype(int)

# accurancy
accuracy = np.mean(predicted_buy_sell == actual_buy_sell)
print(f"Close prediction accuracy: {accuracy}")