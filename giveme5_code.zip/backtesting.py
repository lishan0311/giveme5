from backtesting import Backtest, Strategy
import pandas as pd
import numpy as np 

df = pd.read_csv('backtesting.csv')
df['Date'] = pd.to_datetime(df['Date'], format='%d/%m/%Y %H:%M', errors='coerce')
df.set_index('Date', inplace=True)

def calculate_indicators(df):
    df['ma_200'] = df['Close'].rolling(200, min_periods=50).mean()
    df['vol_ma20'] = df['Volume'].rolling(20).mean().clip(lower=1000)
    
    high_low = df['High'] - df['Low']
    high_close = np.abs(df['High'] - df['Close'].shift())
    low_close = np.abs(df['Low'] - df['Close'].shift())
    df['true_range'] = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
    df['atr_14'] = df['true_range'].ewm(span=14, adjust=False).mean()
    return df
    
df = calculate_indicators(df).dropna()

# Defining a backtesting strategy
class MarketStateStrategy(Strategy):
    lstm_prob_threshold = 0.62
    hmm_conf_threshold = 0.94
    stop_loss_pct = 0.025
    take_profit_pct = 0.055
    trailing_stop_pct = 0.3
    position_size = 0.05
    max_trade_count = 80  # Maximum number of trades to avoid over-trading
    volatility_threshold = 8   # Suspension of trading with a volatility of more than 8 per cent

    atr_stop_mult = 2.0     # ATR Stop Loss Multiplier
    atr_profit_mult = 3.0   # ATR Take Profit Multiplier

    def calculate_position_size(self, ratio=1.0):
        raw_size = self.position_size * self.equity / self.data.Close[-1] * ratio
        return max(1, int(round(raw_size)))  

    def init(self):
        self.lstm_signal = self.data.lstm_signal
        self.hmm_state = self.data.hmm_state
        self.lstm_prob = self.data.lstm_prob
        self.hmm_state_prob = self.data.hmm_state_prob

        self.ma200 = self.data.df['ma_200']
        self.vol_ma20 = self.data.df['vol_ma20']
        self.atr = self.data.df['atr_14']
        
        self.combined_prob = self.I(
            lambda x: x,
            self.lstm_prob * self.hmm_state_prob,
            name='Combined_Prob'
        )

        # Add Volatility Filter
        self.volatility = self.I(lambda x: x, self.data.df['atr_14'] / self.data.Close * 100, name='Volatility')

    def next(self):
        current_close = self.data.Close[-1]
        current_idx = len(self.data)-1
        lstm_signal = int(self.data.lstm_signal[-1])
        hmm_state = int(self.data.hmm_state[-1])
        lstm_prob = float(self.data.lstm_prob[-1])
        hmm_state_prob = float(self.data.hmm_state_prob[-1])

        # Lower positions in times of high volatility
        vol_adjust = 1 - min(0.5, self.volatility[-1]/10)
        position_ratio = 0.5 * vol_adjust  
        
        # Risk management logic
        if self.position:
            # Obtaining the actual entry price (through the last transaction record)
            last_trade = self.trades[-1]
            entry_price = last_trade.entry_price  
            
            # Dynamic Trailing Stop
            self.trades[-1].sl = max(
                self.trades[-1].sl or 0, 
                current_close * (1 - self.trailing_stop_pct)
            )
            
            # Fixed Take Profit and Stop Loss
            if current_close >= entry_price * (1 + self.take_profit_pct):
                self.position.close()
            elif current_close <= entry_price * (1 - self.stop_loss_pct):
                self.position.close()
            return

        # Core trading conditions --------------------------------------------------------
        cond_bull = (
            (hmm_state == 2) &
            (lstm_signal == 1) &
            (lstm_prob > self.lstm_prob_threshold) &
            (hmm_state_prob > self.hmm_conf_threshold) &
            (current_close > self.ma200[current_idx] * 0.98) &
            (self.data.Volume[-1] > self.vol_ma20[-1] * 2.5)  
        )
        
        cond_bear = (
            (hmm_state == 0) &
            (lstm_signal == 0) &
            (lstm_prob > self.lstm_prob_threshold) &
            (hmm_state_prob > self.hmm_conf_threshold)
        )
        
        cond_oscilate = (
            (hmm_state == 1) &
            (self.combined_prob[-1] > 0.7) &
            (lstm_prob > 0.7)
        )
        
        # Execution of transactions------------------------------------------------------------
        atr_value = self.atr[current_idx] or current_close * 0.01
        
        if cond_bull:
            self.buy(
                size = self.calculate_position_size(ratio=1.0),
                sl=current_close - 2*atr_value,  # Setting a Stop Loss with ATR
                tp=current_close + 5*atr_value    # Setting a Take Profit with ATR
            )
            
        elif cond_bear:
            self.sell(
                size = self.calculate_position_size(ratio=1.0),
                sl=current_close + 2*atr_value,
                tp=current_close - 5*atr_value
            )
            
        elif cond_oscilate and lstm_signal == 1:
            self.buy(
                size = self.calculate_position_size(ratio=0.5),
                sl=current_close - self.atr_stop_mult * atr_value,
                tp=current_close + self.atr_profit_mult * atr_value
            )

        # Check if the maximum number of trades has been reached to avoid over-trading
        if len(self.trades) > self.max_trade_count:
            return  # Maximum number of transactions reached and no further transactions executed


        if self.volatility[-1] > self.volatility_threshold:
            return

bt = Backtest(df, MarketStateStrategy, 
             cash=500000,
             commission=.006,  
             margin=1/20,      
             trade_on_close=True,
             hedging=False)    

results = bt.run()
# print result
print(results)