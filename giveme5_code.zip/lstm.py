# load dataset
test = pd.read_csv('bitcoin_2022.csv', index_col='start_time')
test = test.rename(columns={'close': 'Close'})

test['Close'] = np.log(test['Close'] + 1)

columns_to_normalize = ['Close']
scaled_test = scaler.transform(test[['Close']])

# minmaxscaler
test[columns_to_normalize] = scaled_test

test_scaled = pd.DataFrame(scaled_test, columns=['Close'], index=test.index)

def create_sequence(data, window_size):
    X = []
    y = []
    for i in range(window_size, len(data)):
        X.append(data.iloc[i-window_size:i].values)
        y.append(data.iloc[i])
    return np.array(X), np.array(y)

window_size = 80
X_valid, y_valid = create_sequence(test_scaled['Close'], window_size) 
X_valid = X_valid.reshape((X_valid.shape[0], X_valid.shape[1], 1))

test_predictions = model.predict(X_valid)
test_predictions_rescaled = scaler.inverse_transform(test_predictions)
y_rescaled = scaler.inverse_transform(y_valid.reshape(-1, 1))

#diagram
plt.figure(figsize = (14,7))
plt.plot(y_rescaled, color='blue', label= 'Actual Close')
plt.plot(test_predictions_rescaled, color='red', label='Predicted Close')
plt.title('Close Prediction')
plt.xlabel('Time')
plt.ylabel('Close Price')
plt.legend()
plt.show()

test_predicted = model.predict(X_valid).flatten()
test_actual = y_valid.flatten()
test_dates = test.index[-len(y_valid):]

test_predicted_buy_sell = (test_predicted.flatten() > np.roll(test_predicted.flatten(), 3)).astype(int)
test_actual_buy_sell = (test_actual.flatten() > np.roll(test_actual.flatten(), 3)).astype(int)

# create DataFrame
result_df = pd.DataFrame({
    'Date': test_dates,
    'Predicted_Close': test_predicted,
    'Actual_Close': test_actual,
    'Predicted_Buy_Sell': test_predicted_buy_sell,
    'Actual_Buy_Sell': test_actual_buy_sell
})

# save to CSV file
result_df.to_csv('lstm_model_2022.csv', index=False)

print("Prediction results saved to 'results.csv'")